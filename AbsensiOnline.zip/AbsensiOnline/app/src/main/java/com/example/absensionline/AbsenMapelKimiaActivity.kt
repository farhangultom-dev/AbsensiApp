package com.example.absensionline

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.absensionline.Modul.AbsenMapelKimia
import com.example.absensionline.Modul.siswa
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_absen_kelas.*
import java.text.SimpleDateFormat

class AbsenMapelKimiaActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {
    lateinit var mDatabase: DatabaseReference
    private var dataList = ArrayList<siswa>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_absen_mapel_kimia)

        mDatabase = FirebaseDatabase.getInstance().getReference("xmia2")
        rvabsenkelassiswa.layoutManager = LinearLayoutManager(this)
        getkelas("")

        et_cari_nilai.addTextChangedListener(object : TextWatcher {


            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                if (s.toString()!=null){

                    getkelas(s.toString())
                }else{
                    getkelas("")
                }
            }
        })

        val date = System.currentTimeMillis()
        val sdf = SimpleDateFormat("dd-MM-yyyy")
        val dateString: String = sdf.format(date)
        tgl.setText(dateString)
    }

    private fun getkelas(data : String) {

        val query : Query = mDatabase.orderByChild("kelas").startAt(data).endAt(data+"\uf8ff")

        query.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {


                dataList.clear()
                for (getdataSnapshot in dataSnapshot.getChildren()) {

                    val kelas = getdataSnapshot.getValue(siswa::class.java)
                    dataList.add(kelas!!)
                }
                if (dataList.isNotEmpty()) {
                    rvabsenkelassiswa.adapter =
                        AbsenMapelKimia(
                            dataList
                        ) {
                            val intent = Intent(
                                this@AbsenMapelKimiaActivity,
                                InputSiswaActivity::class.java
                            ).putExtra("data", it)


                            startActivity(intent)
                        }

                } else{
                    return
                }


            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@AbsenMapelKimiaActivity, "" + error.message, Toast.LENGTH_LONG).show()
            }
        })
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {
        TODO("Not yet implemented")
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        val text = parent!!.getItemAtPosition(position).toString()
        Toast.makeText(parent.context, text, Toast.LENGTH_SHORT).show()
    }
}