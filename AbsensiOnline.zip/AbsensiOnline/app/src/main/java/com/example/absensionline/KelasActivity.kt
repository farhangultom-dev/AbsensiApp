package com.example.absensionline

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class KelasActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kelas)

        //Find View By Id for button
        val btn = findViewById<Button>(R.id.kelasx) as Button
        val btnxi = findViewById<Button>(R.id.kelasxi) as Button
        val btnxii = findViewById<Button>(R.id.kelasxii) as Button

        //On Click for Button to open PopUp menu
        btn.setOnClickListener {

            /*Create Object Of PopupMenu
             we need to pas  Context and View (Our View is Button so we pass btn to it)
             */

            val popUp = PopupMenu(this@KelasActivity, btn)

            //Inflate our menu Layout.
            popUp.menuInflater.inflate(R.menu.menukelasx, popUp.menu)


            //Set Click Listener on Popup Menu Item
            popUp.setOnMenuItemClickListener { myItem ->

                //Getting Id of selected Item
                val item = myItem!!.itemId

                when (item) {
                    R.id.Xmia1 -> {
                        Toast.makeText(this, "Kamu memilih kelas X MIA 1", Toast.LENGTH_SHORT)
                            .show()
                        startActivity(Intent(this, InputSiswaActivity::class.java))
                    }

                    R.id.Xmia2t -> {
                        Toast.makeText(this, "Kamu memilih kelas X MIA 2", Toast.LENGTH_SHORT)
                            .show()
                        startActivity(Intent(this, InputSiswaActivity::class.java))
                    }

                    R.id.Xmia3 -> {
                        Toast.makeText(this, "Kamu memilih kelas X MIA 1", Toast.LENGTH_SHORT)
                            .show()
                        startActivity(Intent(this, InputSiswaActivity::class.java))
                    }
                }

                true
            }
            popUp.show()


        }

        btnxi.setOnClickListener {

            /*Create Object Of PopupMenu
             we need to pas  Context and View (Our View is Button so we pass btn to it)
             */

            val popUp = PopupMenu(this@KelasActivity, btn)

            //Inflate our menu Layout.
            popUp.menuInflater.inflate(R.menu.menukelasxi, popUp.menu)


            //Set Click Listener on Popup Menu Item
            popUp.setOnMenuItemClickListener { myItem ->

                //Getting Id of selected Item
                val item = myItem!!.itemId

                when (item) {
                    R.id.XIipa1 -> {
                        Toast.makeText(this, "Kamu memilih kelas XI IPA 1", Toast.LENGTH_SHORT)
                            .show()
                        startActivity(Intent(this, InputSiswaXIActivity::class.java))
                    }

                    R.id.XIipa2t -> {
                        Toast.makeText(this, "Kamu memilih kelas XI IPA 2", Toast.LENGTH_SHORT)
                            .show()
                        startActivity(Intent(this, InputSiswaXIActivity::class.java))
                    }

                    R.id.XIIpa3 -> {
                        Toast.makeText(this, "Kamu memilih kelas XI IPA 3", Toast.LENGTH_SHORT)
                            .show()
                        startActivity(Intent(this, InputSiswaXIActivity::class.java))
                    }
                }

                true
            }
            popUp.show()


        }

        btnxii.setOnClickListener {

            /*Create Object Of PopupMenu
             we need to pas  Context and View (Our View is Button so we pass btn to it)
             */

            val popUp = PopupMenu(this@KelasActivity, btn)

            //Inflate our menu Layout.
            popUp.menuInflater.inflate(R.menu.menukelasxii, popUp.menu)


            //Set Click Listener on Popup Menu Item
            popUp.setOnMenuItemClickListener { myItem ->

                //Getting Id of selected Item
                val item = myItem!!.itemId

                when (item) {
                    R.id.XIIipa1 -> {
                        Toast.makeText(this, "Kamu memilih kelas XII IPA 1", Toast.LENGTH_SHORT)
                            .show()
                        startActivity(Intent(this, InputSiswaXIIActivity::class.java))
                    }

                    R.id.XIIipa2t -> {
                        Toast.makeText(this, "Kamu memilih kelas XII IPA 2", Toast.LENGTH_SHORT)
                            .show()
                        startActivity(Intent(this, InputSiswaXIIActivity::class.java))
                    }

                    R.id.XIIIps3 -> {
                        Toast.makeText(this, "Kamu memilih kelas XII IPS 1", Toast.LENGTH_SHORT)
                            .show()
                        startActivity(Intent(this, InputSiswaXIIActivity::class.java))
                    }
                }

                true
            }
            popUp.show()


        }

    }
}
