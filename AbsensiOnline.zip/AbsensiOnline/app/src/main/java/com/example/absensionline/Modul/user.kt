package com.example.absensionline.Modul

import kotlinx.android.parcel.Parcelize
import android.os.Parcelable

@Parcelize
data class user (
    var uid : String ?="",
    var email : String ?="",
    var user_level : String ?= "",
    var user_level_mapel : String?= ""
): Parcelable