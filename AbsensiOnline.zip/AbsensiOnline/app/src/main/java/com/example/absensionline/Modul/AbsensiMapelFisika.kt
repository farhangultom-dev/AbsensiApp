package com.example.absensionline.Modul

import android.app.ProgressDialog
import android.content.Context
import android.telephony.SmsManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.absensionline.R
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.text.SimpleDateFormat

class AbsensiMapelFisika  (private var data: List<siswa>,
                           private val listener: (siswa) -> Unit
) : RecyclerView.Adapter<AbsensiMapelFisika.LeagueViewHolder>() {

    lateinit var ContextAdapter: Context
    lateinit var progressBar: ProgressDialog

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AbsensiMapelFisika.LeagueViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        ContextAdapter = parent.context
        val inflatedView: View =
            layoutInflater.inflate(R.layout.detailsiswa, parent, false)

        return AbsensiMapelFisika.LeagueViewHolder(
            inflatedView
        )
    }

    override fun onBindViewHolder(holder: LeagueViewHolder, position: Int) {
        holder.bindItem(data[position], listener, ContextAdapter, position)

    }

    override fun getItemCount(): Int = data.size

    class LeagueViewHolder(view: View) : RecyclerView.ViewHolder(view) {


        private val tvNama: TextView = view.findViewById(R.id.textView46)
        private val tvNis: TextView = view.findViewById(R.id.textView44)
        private val tvKelas: TextView = view.findViewById(R.id.textView47)
        private val cbhadir: CheckBox = view.findViewById(R.id.cbHadir)
        private val cbalfa: CheckBox = view.findViewById(R.id.checkBox2)
        private val cbsakit: CheckBox = view.findViewById(R.id.checkBox3)
        private val cbizin: CheckBox = view.findViewById(R.id.checkBox4)
        private val tglabsen: TextView = view.findViewById(R.id.tglabsen)
        private val nohportu: TextView = view.findViewById(R.id.nohp)
        private val hadir: TextView = view.findViewById(R.id.tv_hadir)
        private val alfa: TextView = view.findViewById(R.id.tv_alfa)
        private val sakit: TextView = view.findViewById(R.id.tv_sakit)
        private val izin: TextView = view.findViewById(R.id.tv_izin)
        private val telat: CheckBox = view.findViewById(R.id.checkBox)
        private val xtelat: TextView = view.findViewById(R.id.tv_telat)
        private val btnAbsen: Button = view.findViewById(R.id.btn_absen)
        fun bindItem(data: siswa, listener: (siswa) -> Unit, context: Context, position: Int) {

            tvNama.text = data.nama
            tvNis.text = data.nis
            tvKelas.text = data.kelas
            nohportu.text = data.nohportu

            cbhadir.setOnClickListener(){
                val uid_tglabsen = tglabsen.text.toString()
                val uid_absen = tvNis.text.toString()
                val status = hadir.text.toString()
                val uid_kelas = tvKelas.text.toString()
                val refUsers = FirebaseDatabase.getInstance().reference.child("AbsenMapelFisika/$uid_tglabsen/$uid_kelas").child(uid_absen)
                refUsers!!.addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(p0: DataSnapshot) {
                        if (p0.exists()) {
                            val absenMapel: absenmapel = p0.getValue(absenmapel::class.java)!!

                            val stat = absenMapel.status
                            val nis = absenMapel.nis
                            val tgl = absenMapel.tgl_absen
                            if (stat == "hadir" && nis == uid_absen && tgl == uid_tglabsen ) {
                                Toast.makeText(context, "Siswa Sudah Di Absen", Toast.LENGTH_SHORT).show()

                                cbhadir.setEnabled(false); // disable checkbox
                                cbsakit.setEnabled(false); // disable checkbox
                                cbizin.setEnabled(false); // disable checkbox
                                cbalfa.setEnabled(false)
                                telat.setEnabled(false)
                                cbhadir.setChecked(false)
                                btnAbsen.setEnabled(false);
                            }
                            if (stat == null && nis == null && tgl == null) {
                                Toast.makeText(context, "Silahkan Absen Siswa", Toast.LENGTH_SHORT).show()
                            }

                        }
                    }

                    override fun onCancelled(p0: DatabaseError) {

                    }

                })
            }
            cbalfa.setOnClickListener(){
                val uid_tglabsen = tglabsen.text.toString()
                val uid_absen = tvNis.text.toString()
                val status = hadir.text.toString()
                val uid_kelas = tvKelas.text.toString()
                val refUsers = FirebaseDatabase.getInstance().reference.child("AbsenMapelFisika/$uid_tglabsen/$uid_kelas").child(uid_absen)
                refUsers!!.addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(p0: DataSnapshot) {
                        if (p0.exists()) {
                            val absenMapel: absenmapel = p0.getValue(absenmapel::class.java)!!

                            val stat = absenMapel.status
                            val nis = absenMapel.nis
                            val tgl = absenMapel.tgl_absen
                            if (stat == "alfa" && nis == uid_absen && tgl == uid_tglabsen ) {
                                Toast.makeText(context, "Siswa Sudah Di Absen", Toast.LENGTH_SHORT).show()

                                cbhadir.setEnabled(false); // disable checkbox
                                cbsakit.setEnabled(false); // disable checkbox
                                cbizin.setEnabled(false); // disable checkbox
                                cbalfa.setEnabled(false)
                                telat.setEnabled(false)
                                cbhadir.setChecked(false)
                                btnAbsen.setEnabled(false);
                            }
                            if (stat == null && nis == null && tgl == null) {
                                Toast.makeText(context, "Silahkan Absen Siswa", Toast.LENGTH_SHORT).show()
                            }

                        }
                    }

                    override fun onCancelled(p0: DatabaseError) {

                    }

                })
            }
            cbsakit.setOnClickListener(){
                val uid_tglabsen = tglabsen.text.toString()
                val uid_absen = tvNis.text.toString()
                val status = hadir.text.toString()
                val uid_kelas = tvKelas.text.toString()
                val refUsers = FirebaseDatabase.getInstance().reference.child("AbsenMapelFisika/$uid_tglabsen/$uid_kelas").child(uid_absen)
                refUsers!!.addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(p0: DataSnapshot) {
                        if (p0.exists()) {
                            val absenMapel: absenmapel = p0.getValue(absenmapel::class.java)!!

                            val stat = absenMapel.status
                            val nis = absenMapel.nis
                            val tgl = absenMapel.tgl_absen
                            if (stat == "sakit" && nis == uid_absen && tgl == uid_tglabsen ) {
                                Toast.makeText(context, "Siswa Sudah Di Absen", Toast.LENGTH_SHORT).show()

                                cbhadir.setEnabled(false); // disable checkbox
                                cbsakit.setEnabled(false); // disable checkbox
                                cbizin.setEnabled(false); // disable checkbox
                                cbalfa.setEnabled(false)
                                telat.setEnabled(false)
                                cbhadir.setChecked(false)
                                btnAbsen.setEnabled(false);
                            }
                            if (stat == null && nis == null && tgl == null) {
                                Toast.makeText(context, "Silahkan Absen Siswa", Toast.LENGTH_SHORT).show()
                            }

                        }
                    }

                    override fun onCancelled(p0: DatabaseError) {

                    }

                })
            }
            cbizin.setOnClickListener(){
                val uid_tglabsen = tglabsen.text.toString()
                val uid_absen = tvNis.text.toString()
                val status = hadir.text.toString()
                val uid_kelas = tvKelas.text.toString()
                val refUsers = FirebaseDatabase.getInstance().reference.child("AbsenMapelFisika/$uid_tglabsen/$uid_kelas").child(uid_absen)
                refUsers!!.addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(p0: DataSnapshot) {
                        if (p0.exists()) {
                            val absenKelas: absenkelas = p0.getValue(absenkelas::class.java)!!

                            val stat = absenKelas.status
                            val nis = absenKelas.nis
                            val tgl = absenKelas.tgl_absen
                            if (stat == "izin" && nis == uid_absen && tgl == uid_tglabsen ) {
                                Toast.makeText(context, "Siswa Sudah Di Absen", Toast.LENGTH_SHORT).show()

                                cbhadir.setEnabled(false); // disable checkbox
                                cbsakit.setEnabled(false); // disable checkbox
                                cbizin.setEnabled(false); // disable checkbox
                                cbalfa.setEnabled(false)
                                telat.setEnabled(false)
                                cbhadir.setChecked(false)
                                btnAbsen.setEnabled(false);
                            }
                            if (stat == null && nis == null && tgl == null) {
                                Toast.makeText(context, "Silahkan Absen Siswa", Toast.LENGTH_SHORT).show()
                            }

                        }
                    }

                    override fun onCancelled(p0: DatabaseError) {

                    }

                })
            }
            telat.setOnClickListener(){
                val uid_tglabsen = tglabsen.text.toString()
                val uid_absen = tvNis.text.toString()
                val status = hadir.text.toString()
                val uid_kelas = tvKelas.text.toString()
                val refUsers = FirebaseDatabase.getInstance().reference.child("AbsenMapelFisika/$uid_tglabsen/$uid_kelas").child(uid_absen)
                refUsers!!.addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(p0: DataSnapshot) {
                        if (p0.exists()) {
                            val absenKelas: absenkelas = p0.getValue(absenkelas::class.java)!!

                            val stat = absenKelas.status
                            val stat2 = absenKelas.status2
                            val nis = absenKelas.nis
                            val tgl = absenKelas.tgl_absen
                            if (stat2 == "telat" && nis == uid_absen && tgl == uid_tglabsen ) {
                                Toast.makeText(context, "Siswa Sudah Di Absen", Toast.LENGTH_SHORT).show()

                                cbhadir.setEnabled(false); // disable checkbox
                                cbsakit.setEnabled(false); // disable checkbox
                                cbizin.setEnabled(false); // disable checkbox
                                cbalfa.setEnabled(false)
                                telat.setEnabled(false)
                                cbhadir.setChecked(false)
                                btnAbsen.setEnabled(false);
                            }
                            if (stat == null && nis == null && tgl == null) {
                                Toast.makeText(context, "Silahkan Absen Siswa", Toast.LENGTH_SHORT).show()
                            }

                        }
                    }

                    override fun onCancelled(p0: DatabaseError) {

                    }

                })
            }



            btnAbsen.setOnClickListener() {

                if (cbhadir.isChecked) {
                    val uid_tglabsen = tglabsen.text.toString()
                    val uid_absen = tvNis.text.toString()
                    val status = hadir.text.toString()
                    val uid_kelas = tvKelas.text.toString()
                    val refUsers = FirebaseDatabase.getInstance().reference.child("AbsenMapelFisika/$uid_tglabsen/$uid_kelas").child(uid_absen)

                    refUsers.setValue(
                        absenmapel(
                            uid_absen,
                            uid_tglabsen,
                            tvNama.text.toString(),
                            tvNis.text.toString(),
                            status

                        )
                    )
                        .addOnSuccessListener {
                            Toast.makeText(context, "Siswa Berhasil Di Absen", Toast.LENGTH_SHORT).show()
                        }
                        .addOnFailureListener {

                        }




                }
                else if (cbalfa.isChecked){
                    val uid_tglabsen = tglabsen.text.toString()
                    val uid_absen = tvNis.text.toString()
                    val status = alfa.text.toString()
                    val uid_nama = tvNama.text.toString()
                    val uid_kelas = tvKelas.text.toString()
                    val refUsers = FirebaseDatabase.getInstance().reference.child("AbsenMapelFisika/$uid_tglabsen/$uid_kelas").child(uid_absen)

                    refUsers.setValue(
                        absenkelas(
                            uid_absen,
                            uid_tglabsen,
                            tvNama.text.toString(),
                            tvNis.text.toString(),
                            status

                        )
                    )
                        .addOnSuccessListener {
                            Toast.makeText(context, "Siswa Berhasil Di Absen", Toast.LENGTH_SHORT).show()
                            var obj=SmsManager.getDefault()
                            obj.sendTextMessage(nohportu.text.toString(),
                                null,"Anak Anda Yang Bernama $uid_nama Kelas $uid_kelas Berstatus Alfa Di Mata Pelajaran Fisika Dan Tidak Hadir Dalam Kegiatan Belajar Di Mata Pelajaran Fisika",null,null)

                        }
                        .addOnFailureListener {

                        }




                }else if (cbsakit.isChecked) {
                    val uid_tglabsen = tglabsen.text.toString()
                    val uid_absen = tvNis.text.toString()
                    val status = sakit.text.toString()
                    val uid_nama = tvNama.text.toString()
                    val uid_kelas = tvKelas.text.toString()
                    val refUsers = FirebaseDatabase.getInstance().reference.child("AbsenMapelFisika/$uid_tglabsen/$uid_kelas").child(uid_absen)
                    refUsers.setValue(
                        absenkelas(
                            uid_absen,
                            uid_tglabsen,
                            tvNama.text.toString(),
                            tvNis.text.toString(),
                            status

                        )
                    )
                        .addOnSuccessListener {
                            //Toast.makeText(context, "Siswa Berhasil Di Absen", Toast.LENGTH_SHORT).show()
                            Toast.makeText(context, "Siswa Berhasil Di Absen", Toast.LENGTH_SHORT).show()
                            var obj=SmsManager.getDefault()
                            obj.sendTextMessage(nohportu.text.toString(),
                                null,"Anak Anda Yang Bernama $uid_nama Kelas $uid_kelas Berstatus Sakit Di Mata Pelajaran Fisika Dan Tidak Hadir Dalam Kegiatan Belajar Di Mata Pelajaran Fisika",null,null)

                        }
                        .addOnFailureListener {

                        }


                }else if (cbizin.isChecked){
                    val uid_tglabsen = tglabsen.text.toString()
                    val uid_absen = tvNis.text.toString()
                    val status = izin.text.toString()
                    val uid_nama = tvNama.text.toString()
                    val uid_kelas = tvKelas.text.toString()
                    val refUsers = FirebaseDatabase.getInstance().reference.child("AbsenMapelFisika/$uid_tglabsen/$uid_kelas").child(uid_absen)

                    refUsers.setValue(
                        absenkelas(
                            uid_absen,
                            uid_tglabsen,
                            tvNama.text.toString(),
                            tvNis.text.toString(),
                            status

                        )
                    )
                        .addOnSuccessListener {
                            //Toast.makeText(context, "Siswa Berhasil Di Absen", Toast.LENGTH_SHORT).show()
                            Toast.makeText(context, "Siswa Berhasil Di Absen", Toast.LENGTH_SHORT).show()
                            var obj=SmsManager.getDefault()
                            obj.sendTextMessage(nohportu.text.toString(),
                                null,"Anak Anda Yang Bernama $uid_nama Kelas $uid_kelas Berstatus Izin Di Mata Pelajaran Fisika Dan Tidak Hadir Dalam Kegiatan Belajar Di Mata Pelajaran Fisika",null,null)
                        }
                        .addOnFailureListener {

                        }


                }else if (telat.isChecked){
                    val uid_tglabsen = tglabsen.text.toString()
                    val uid_absen = tvNis.text.toString()
                    val status = hadir.text.toString()
                    val uid_nama = tvNama.text.toString()
                    val uid_kelas = tvKelas.text.toString()
                    val refUsers = FirebaseDatabase.getInstance().reference.child("AbsenMapelFisika/$uid_tglabsen/$uid_kelas").child(uid_absen)
                    refUsers.setValue(
                        absenkelas(
                            uid_absen,
                            uid_tglabsen,
                            tvNama.text.toString(),
                            tvNis.text.toString(),
                            status,
                            xtelat.text.toString()

                        )
                    )
                        .addOnSuccessListener {
                            //Toast.makeText(context, "Siswa Berhasil Di Absen", Toast.LENGTH_SHORT).show()
                            Toast.makeText(context, "Siswa Berhasil Di Absen", Toast.LENGTH_SHORT).show()
                            var obj=SmsManager.getDefault()
                            obj.sendTextMessage(nohportu.text.toString(),
                                null,"Anak Anda Yang Bernama $uid_nama Kelas $uid_kelas Berstatus Telat Di Mata Pelajaran Fisika Dan Tidak Hadir Dalam Kegiatan Belajar Di Mata Pelajaran Fisika",null,null)
                        }
                        .addOnFailureListener {

                        }

                }



            }

            val date = System.currentTimeMillis()
            val sdf = SimpleDateFormat("dd-MM-yyyy ")
            val dateString: String = sdf.format(date)
            tglabsen.setText(dateString)



        }


    }
}