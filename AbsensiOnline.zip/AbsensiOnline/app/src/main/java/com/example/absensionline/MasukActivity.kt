package com.example.absensionline

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_masuk.*

class MasukActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    lateinit var preferences: Preferences
    lateinit var progressBar: ProgressDialog
    var firebaseUser: FirebaseUser? = null
    lateinit var mdatabase: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_masuk)
        preferences = Preferences(this)
        auth = FirebaseAuth.getInstance()

        progressBar = ProgressDialog(this)
        progressBar.setMessage("Mohon tunggu...")


        preferences.setValues("onboarding", "1")
        if (preferences.getValues("status").equals("1")) {
            finishAffinity()

            val intent = Intent(
                this,
                DashboardActivity::class.java
            )
            startActivity(intent)
        }

        btn_signup.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
        btn_signin.setOnClickListener {
            progressBar.show()
            doLogin()
        }
    }

    private fun doLogin() {

        if (et_email.text.toString().isEmpty()) {
            progressBar.dismiss()
            et_email.error = "Masukkan Email Kamu"
            et_email.requestFocus()
            return
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(et_email.text.toString()).matches()) {
            progressBar.dismiss()
            et_email.error = "Masukkan Valid Email Kamu"
            et_email.requestFocus()
            return
        }

        if (et_pass.text.toString().isEmpty()) {
            progressBar.dismiss()
            et_pass.error = "Masukkan Password Kamu"
            et_pass.requestFocus()
            return
        }

        auth.signInWithEmailAndPassword(et_email.text.toString(), et_pass.text.toString())
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {

                    val user = auth.currentUser
                    updateUI(user)
                } else {

                    updateUI(null)
                }

            }
    }

    private fun updateUI(currentUser: FirebaseUser?) {



        if (currentUser != null) {
            if (currentUser.isEmailVerified) {

                firebaseUser = FirebaseAuth.getInstance().currentUser
                mdatabase = FirebaseDatabase.getInstance().reference.child("user").child(firebaseUser!!.uid)

                mdatabase.addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(user: DataSnapshot) {

                        if (user.exists()){

                            progressBar.dismiss()
                            startActivity(Intent(this@MasukActivity, DashboardActivity::class.java))
                            preferences.setValues("status", "1")
                            finish()
                        }

                    }

                    override fun onCancelled(user: DatabaseError) {

                    }

                })

            } else {
                progressBar.dismiss()
                Toast.makeText(
                    baseContext, "Verifikasi email anda",
                    Toast.LENGTH_SHORT
                ).show()
            }
        } else {
            progressBar.dismiss()
            Toast.makeText(
                baseContext, "Login Gagal.",
                Toast.LENGTH_SHORT
            ).show()

        }

    }

}