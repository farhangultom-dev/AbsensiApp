package com.example.absensionline

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.absensionline.Modul.user
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_absen_mapel.*
import kotlinx.android.synthetic.main.activity_laporan_presensi.*

class LaporanPresensiActivity : AppCompatActivity() {
    lateinit var mDatabase: DatabaseReference
    lateinit var preferences: Preferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_laporan_presensi)

        preferences = Preferences(this)
        val firebaseUser = FirebaseAuth.getInstance().currentUser
        val refUsers = FirebaseDatabase.getInstance().reference.child("user").child(firebaseUser!!.uid)
        refUsers.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(p0: DataSnapshot) {

                if (p0.exists()) {
                    val user: user = p0.getValue(user::class.java)!!
                    if (user.user_level.toString() == ("admin")) {
                        cv_absenkelas.visibility = View.VISIBLE
                        cv_absenpiket.visibility = View.VISIBLE
                        cv_absenmapel.visibility = View.VISIBLE

                    }else{
                        cv_absenpiket.visibility = View.GONE

                    }


                }

            }

            override fun onCancelled(p0: DatabaseError) {

            }

        })
    }

    fun absenkelas(view: View) {
        startActivity(Intent(this, AbsenKelasActivity::class.java))
    }

    fun absenmapel(view: View) {
        startActivity(Intent(this, AbsenMapelActivity::class.java))
    }

    fun piket(view: View) {
        startActivity(Intent(this, AbsenPiketActivity::class.java))
    }
}