package com.example.absensionline

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import com.example.absensionline.Modul.siswa
import com.example.absensionline.Modul.xmia1
import com.example.absensionline.Modul.xmia2
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_input_siswa.*
import java.util.*

class InputSiswaXIActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input_siswa_x_i)

        val spinner = findViewById<Spinner>(R.id.spinner)
        val adapter = ArrayAdapter.createFromResource(
            this,
            R.array.KelasXI,
            android.R.layout.simple_spinner_item
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        spinner.setOnItemSelectedListener(this)

        btnTambahSiswa.setOnClickListener {
            tambahSiswa()
        }
    }

    private fun tambahSiswa() {  val progressBar = ProgressDialog(this)
        progressBar.setMessage("Mohon tunggu...")
        progressBar.show()

        val uid_siswa = UUID.randomUUID()
        val kelas = spinner.selectedItem.toString()

        if (kelas == ("XI MIA 1")) {

            val db = FirebaseDatabase.getInstance().getReference("ximia1/$uid_siswa")


            db.setValue(
                xmia1(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )

            val dbs = FirebaseDatabase.getInstance().getReference("siswa/$uid_siswa")


            dbs.setValue(
                siswa(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()



                )
            )
                .addOnSuccessListener {
                    progressBar.dismiss()
                    startActivity(Intent(this, InputSiswaActivity::class.java))
                    finish()
                }
                .addOnFailureListener {

                }
        }
        else if (kelas == ("XI MIA 2")){
            val db = FirebaseDatabase.getInstance().getReference("ximia2/$uid_siswa")


            db.setValue(
                xmia2(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )

            val dbs = FirebaseDatabase.getInstance().getReference("siswa/$uid_siswa")


            dbs.setValue(
                siswa(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )


                .addOnSuccessListener {
                    progressBar.dismiss()
                    startActivity(Intent(this, InputSiswaActivity::class.java))
                    finish()
                }
                .addOnFailureListener {

                }
        }
        else if (kelas == ("XI MIA 3")){
            val db = FirebaseDatabase.getInstance().getReference("ximia3/$uid_siswa")


            db.setValue(
                xmia2(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )

            val dbs = FirebaseDatabase.getInstance().getReference("siswa/$uid_siswa")


            dbs.setValue(
                siswa(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )


                .addOnSuccessListener {
                    progressBar.dismiss()
                    startActivity(Intent(this, InputSiswaActivity::class.java))
                    finish()
                }
                .addOnFailureListener {

                }
        }
        else if (kelas == ("XI IIS 1")){
            val db = FirebaseDatabase.getInstance().getReference("xiiis1/$uid_siswa")


            db.setValue(
                xmia2(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )

            val dbs = FirebaseDatabase.getInstance().getReference("siswa/$uid_siswa")


            dbs.setValue(
                siswa(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )


                .addOnSuccessListener {
                    progressBar.dismiss()
                    startActivity(Intent(this, InputSiswaActivity::class.java))
                    finish()
                }
                .addOnFailureListener {

                }
        }
        else if (kelas == ("XI IIS 2")){
            val db = FirebaseDatabase.getInstance().getReference("xiiis2/$uid_siswa")


            db.setValue(
                xmia2(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )

            val dbs = FirebaseDatabase.getInstance().getReference("siswa/$uid_siswa")


            dbs.setValue(
                siswa(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )


                .addOnSuccessListener {
                    progressBar.dismiss()
                    startActivity(Intent(this, InputSiswaActivity::class.java))
                    finish()
                }
                .addOnFailureListener {

                }
        }
        else if (kelas == ("XI IIS 3")){
            val db = FirebaseDatabase.getInstance().getReference("xiiis3/$uid_siswa")


            db.setValue(
                xmia2(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )

            val dbs = FirebaseDatabase.getInstance().getReference("siswa/$uid_siswa")


            dbs.setValue(
                siswa(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )


                .addOnSuccessListener {
                    progressBar.dismiss()
                    startActivity(Intent(this, InputSiswaActivity::class.java))
                    finish()
                }
                .addOnFailureListener {

                }
        }else if (kelas == ("XI IIS 4")){
            val db = FirebaseDatabase.getInstance().getReference("xiiis4/$uid_siswa")


            db.setValue(
                xmia2(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )

            val dbs = FirebaseDatabase.getInstance().getReference("siswa/$uid_siswa")


            dbs.setValue(
                siswa(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )


                .addOnSuccessListener {
                    progressBar.dismiss()
                    startActivity(Intent(this, InputSiswaActivity::class.java))
                    finish()
                }
                .addOnFailureListener {

                }
        }else if (kelas == ("XI IIS 5")){
            val db = FirebaseDatabase.getInstance().getReference("xiiis5/$uid_siswa")


            db.setValue(
                xmia2(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )

            val dbs = FirebaseDatabase.getInstance().getReference("siswa/$uid_siswa")


            dbs.setValue(
                siswa(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )


                .addOnSuccessListener {
                    progressBar.dismiss()
                    startActivity(Intent(this, InputSiswaActivity::class.java))
                    finish()
                }
                .addOnFailureListener {

                }
        }
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {
        TODO("Not yet implemented")
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        val text = parent!!.getItemAtPosition(position).toString()
        Toast.makeText(parent.context, text, Toast.LENGTH_SHORT).show()
    }
}