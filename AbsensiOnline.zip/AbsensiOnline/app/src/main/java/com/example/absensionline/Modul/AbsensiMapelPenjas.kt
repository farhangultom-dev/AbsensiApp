package com.example.absensionline.Modul

import android.app.ProgressDialog
import android.content.Context
import android.telephony.SmsManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.absensionline.R
import com.google.firebase.database.FirebaseDatabase
import java.text.SimpleDateFormat

class AbsensiMapelPenjas (private var data: List<siswa>,
                          private val listener: (siswa) -> Unit
) : RecyclerView.Adapter<AbsensiMapelPenjas.LeagueViewHolder>() {

    lateinit var ContextAdapter: Context
    lateinit var progressBar: ProgressDialog

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AbsensiMapelPenjas.LeagueViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        ContextAdapter = parent.context
        val inflatedView: View =
            layoutInflater.inflate(R.layout.detailsiswa, parent, false)

        return AbsensiMapelPenjas.LeagueViewHolder(
            inflatedView
        )
    }

    override fun onBindViewHolder(holder: AbsensiMapelPenjas.LeagueViewHolder, position: Int) {
        holder.bindItem(data[position], listener, ContextAdapter, position)

    }

    override fun getItemCount(): Int = data.size

    class LeagueViewHolder(view: View) : RecyclerView.ViewHolder(view) {


        private val tvNama: TextView = view.findViewById(R.id.textView46)
        private val tvNis: TextView = view.findViewById(R.id.textView44)
        private val tvKelas: TextView = view.findViewById(R.id.textView47)
        private val cbhadir: CheckBox = view.findViewById(R.id.cbHadir)
        private val cbalfa: CheckBox = view.findViewById(R.id.checkBox2)
        private val cbsakit: CheckBox = view.findViewById(R.id.checkBox3)
        private val cbizin: CheckBox = view.findViewById(R.id.checkBox4)
        private val tglabsen: TextView = view.findViewById(R.id.tglabsen)
        private val nohportu: TextView = view.findViewById(R.id.nohp)

        fun bindItem(data: siswa, listener: (siswa) -> Unit, context: Context, position: Int) {

            tvNama.text = data.nama
            tvNis.text = data.nis
            tvKelas.text = data.kelas
            nohportu.text = data.nohportu


            cbhadir.setOnClickListener {


                val uid_tglabsen = tglabsen.text.toString()
                val uid_kelas = tvKelas.text.toString()
                val uid_nis = tvNis.text.toString()
                val db = FirebaseDatabase.getInstance().getReference("AbsenMapelPenjas/Hadir/$uid_kelas/$uid_tglabsen/$uid_nis")

                db.setValue(
                    absenmapel(
                        tvNama.text.toString(),
                        tvNis.text.toString()
                    )
                )
                    .addOnSuccessListener {
                        if (cbhadir.isChecked) {
                            cbalfa.setEnabled(false); // disable checkbox
                            cbsakit.setEnabled(false); // disable checkbox
                            cbizin.setEnabled(false); // disable checkbox
                        }else{
                            cbalfa.setEnabled(true); // disable checkbox
                            cbsakit.setEnabled(true); // disable checkbox
                            cbizin.setEnabled(true); // disable checkbox
                        }

                    }
                    .addOnFailureListener {

                    }
            }

            cbalfa.setOnClickListener {

                val uid_tglabsen = tglabsen.text.toString()
                val uid_kelas = tvKelas.text.toString()
                val uid_nis = tvNis.text.toString()
                val uid_nama = tvNama.text.toString()
                val db = FirebaseDatabase.getInstance().getReference("AbsenMapelPenjas/alfa/$uid_kelas/$uid_tglabsen/$uid_nis")

                db.setValue(
                    absenmapel(
                        tvNama.text.toString(),
                        tvNis.text.toString()
                    )
                )
                    .addOnSuccessListener {
                        if (cbalfa.isChecked) {
                            cbhadir.setEnabled(false); // disable checkbox
                            cbsakit.setEnabled(false); // disable checkbox
                            cbizin.setEnabled(false); // disable checkbox

                            var obj= SmsManager.getDefault()
                            obj.sendTextMessage(nohportu.text.toString(),
                                null,"Anak Anda Yang Bernama $uid_nama Kelas $uid_kelas Berstatus Alfa Di Mata Pelajaran Penjas Dan Tidak Hadir Dalam Kegiatan Belajar Di Mata Pelajaran Penjas",null,null)
                        }else {
                            cbhadir.setEnabled(true); // disable checkbox
                            cbsakit.setEnabled(true); // disable checkbox
                            cbizin.setEnabled(true); // disable checkbox
                        }
                    }
                    .addOnFailureListener {

                    }
            }

            cbsakit.setOnClickListener {

                val uid_tglabsen = tglabsen.text.toString()
                val uid_kelas = tvKelas.text.toString()
                val uid_nis = tvNis.text.toString()
                val uid_nama = tvNama.text.toString()
                val db = FirebaseDatabase.getInstance().getReference("AbsenMapelPenjas/sakit/$uid_kelas/$uid_tglabsen/$uid_nis")

                db.setValue(
                    absenmapel(
                        tvNama.text.toString(),
                        tvNis.text.toString()
                    )
                )
                    .addOnSuccessListener {
                        if (cbsakit.isChecked) {
                            cbhadir.setEnabled(false); // disable checkbox
                            cbalfa.setEnabled(false); // disable checkbox
                            cbizin.setEnabled(false); // disable checkbox

                            var obj= SmsManager.getDefault()
                            obj.sendTextMessage(nohportu.text.toString(),
                                null,"Anak Anda Yang Bernama $uid_nama Kelas $uid_kelas Berstatus Sakit Di Mata Pelajaran Penjas Dan Tidak Hadir Dalam Kegiatan Belajar Di Mata Pelajaran Penjas",null,null)
                        }else {
                            cbhadir.setEnabled(true); // disable checkbox
                            cbalfa.setEnabled(true); // disable checkbox
                            cbizin.setEnabled(true); // disable checkbox
                        }
                    }
                    .addOnFailureListener {

                    }
            }

            cbizin.setOnClickListener {

                val uid_tglabsen = tglabsen.text.toString()
                val uid_kelas = tvKelas.text.toString()
                val uid_nis = tvNis.text.toString()
                val uid_nama = tvNama.text.toString()
                val db = FirebaseDatabase.getInstance().getReference("AbsenMapelPenjas/izin/$uid_kelas/$uid_tglabsen/$uid_nis")

                db.setValue(
                    absenmapel(
                        tvNama.text.toString(),
                        tvNis.text.toString()
                    )
                )
                    .addOnSuccessListener {
                        if (cbizin.isChecked) {
                            cbhadir.setEnabled(false); // disable checkbox
                            cbsakit.setEnabled(false); // disable checkbox
                            cbalfa.setEnabled(false); // disable checkbox

                            var obj= SmsManager.getDefault()
                            obj.sendTextMessage(nohportu.text.toString(),
                                null,"Anak Anda Yang Bernama $uid_nama Kelas $uid_kelas Berstatus Izin Di Mata Pelajaran Penjas Dan Tidak Hadir Dalam Kegiatan Belajar Di Mata Pelajaran Penjas",null,null)
                        }else {
                            cbhadir.setEnabled(true); // disable checkbox
                            cbsakit.setEnabled(true); // disable checkbox
                            cbalfa.setEnabled(true); // disable checkbox
                        }
                    }
                    .addOnFailureListener {

                    }
            }

            val date = System.currentTimeMillis()
            val sdf = SimpleDateFormat("dd-MM-yyyy ")
            val dateString: String = sdf.format(date)
            tglabsen.setText(dateString)



        }


    }
}