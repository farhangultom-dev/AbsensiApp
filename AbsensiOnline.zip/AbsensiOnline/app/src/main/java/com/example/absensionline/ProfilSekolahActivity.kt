package com.example.absensionline

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ProfilSekolahActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profil_sekolah)
    }
}