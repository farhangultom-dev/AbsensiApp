package com.example.absensionline

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class StrukturActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_struktur)
    }

    fun visimisi(view: View) {
        startActivity(Intent(this, ProfilSekolahActivity::class.java))
    }
}