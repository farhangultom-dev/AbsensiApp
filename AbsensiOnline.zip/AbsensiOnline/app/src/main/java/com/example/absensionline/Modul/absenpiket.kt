package com.example.absensionline.Modul

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


@Parcelize
class absenpiket (
    var uid_absen : String="",
    var tgl_absen : String="",
    var nama : String ?="",
    var nis : String ?="",
    var status : String ?="",
    var status2 : String?=""
): Parcelable