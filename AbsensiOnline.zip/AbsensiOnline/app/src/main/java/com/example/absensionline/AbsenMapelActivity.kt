package com.example.absensionline

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.R.layout.simple_list_item_1
import android.content.Intent
import android.view.View
import android.widget.Toast
import com.example.absensionline.Modul.AbsensiMapelBing
import com.example.absensionline.Modul.user
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_absen_mapel.*
import kotlinx.android.synthetic.main.activity_dashboard.*

class AbsenMapelActivity : AppCompatActivity() {
    lateinit var mDatabase: DatabaseReference
    lateinit var preferences: Preferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_absen_mapel)

        preferences = Preferences(this)
        val firebaseUser = FirebaseAuth.getInstance().currentUser
        val refUsers = FirebaseDatabase.getInstance().reference.child("user").child(firebaseUser!!.uid)
        refUsers.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(p0: DataSnapshot) {

                if (p0.exists()) {
                    val user: user = p0.getValue(user::class.java)!!
                    if (user.user_level_mapel.toString() == ("guruBiologi")) {
                        cardView5.visibility = View.GONE
                        cardView4.visibility = View.VISIBLE
                        cardView6.visibility = View.GONE
                        cardView7.visibility = View.GONE
                        cardView11.visibility = View.GONE
                        cardView10.visibility = View.GONE
                        cardView9.visibility = View.GONE
                        cardView12.visibility = View.GONE
                        cv_bing.visibility = View.GONE
                        cv_penjas.visibility = View.GONE

                    }
                    if (user.user_level_mapel.toString() == ("guruSejarah")) {
                        cardView5.visibility = View.GONE
                        cardView4.visibility = View.GONE
                        cardView6.visibility = View.GONE
                        cardView7.visibility = View.GONE
                        cardView11.visibility = View.GONE
                        cardView10.visibility = View.VISIBLE
                        cardView6.visibility = View.GONE
                        cardView9.visibility = View.GONE
                        cardView6.visibility = View.GONE
                        cardView12.visibility = View.GONE
                        cv_bing.visibility = View.GONE
                        cv_penjas.visibility = View.GONE

                    }
                    if (user.user_level_mapel.toString() == ("guruKimia")){
                        cardView5.visibility = View.GONE
                        cardView4.visibility = View.GONE
                        cardView7.visibility = View.GONE
                        cardView11.visibility = View.GONE
                        cardView10.visibility = View.GONE
                        cardView6.visibility = View.VISIBLE
                        cardView9.visibility = View.GONE
                        cardView12.visibility = View.GONE
                        cv_bing.visibility = View.GONE
                        cv_penjas.visibility = View.GONE

                    }
                    if (user.user_level_mapel.toString() == ("guruFisika")){
                        cardView5.visibility = View.VISIBLE
                        cardView4.visibility = View.GONE
                        cardView6.visibility = View.GONE
                        cardView7.visibility = View.GONE
                        cardView11.visibility = View.GONE
                        cardView10.visibility = View.GONE
                        cardView6.visibility = View.GONE
                        cardView9.visibility = View.GONE
                        cardView6.visibility = View.GONE
                        cardView12.visibility = View.GONE
                        cv_bing.visibility = View.GONE
                        cv_penjas.visibility = View.GONE

                    }
                    if (user.user_level.toString() == ("admin")){
                        cardView5.visibility = View.VISIBLE
                        cardView4.visibility = View.VISIBLE
                        cardView7.visibility = View.VISIBLE
                        cardView11.visibility = View.VISIBLE
                        cardView10.visibility = View.VISIBLE
                        cardView6.visibility = View.VISIBLE
                        cardView9.visibility = View.VISIBLE
                        cardView12.visibility = View.VISIBLE
                        cv_bing.visibility = View.VISIBLE
                        cv_penjas.visibility = View.VISIBLE

                    }
                    if (user.user_level_mapel.toString() == ("guruEkonomi")){
                        cardView5.visibility = View.GONE
                        cardView4.visibility = View.GONE
                        cardView7.visibility = View.VISIBLE
                        cardView11.visibility = View.GONE
                        cardView10.visibility = View.GONE
                        cardView6.visibility = View.GONE
                        cardView9.visibility = View.GONE
                        cardView12.visibility = View.GONE
                        cv_bing.visibility = View.GONE
                        cv_penjas.visibility = View.GONE

                    }


                }

            }

            override fun onCancelled(p0: DatabaseError) {

            }

        })
    }

    fun fisika(view: View) {
        startActivity(Intent(this, AbsenMapelFisikaActivity::class.java))
    }

    fun biologi(view: View) {
        startActivity(Intent(this, AbsenMapelBiologiActivity::class.java))
    }

    fun ekonomi(view: View) {
        startActivity(Intent(this, AbsenMapelEkonomiActivity::class.java))
    }
    fun kimia(view: View) {
        startActivity(Intent(this, AbsenMapelKimiaActivity::class.java))
    }

    fun geografi(view: View) {
        startActivity(Intent(this, AbsenMapelGeografiActivity::class.java))
    }
    fun sejarah(view: View) {
        startActivity(Intent(this, AbsenMapelSejarahActivity::class.java))
    }
    fun matematika(view: View) {
        startActivity(Intent(this, AbsenMapelMatematikaActivity::class.java))
    }
    fun BIndo(view: View) {
        startActivity(Intent(this, AbsensiMapelBindoActivity::class.java))
    }
    fun BIng(view: View) {
        startActivity(Intent(this, AbsensiMapelBingActivity::class.java))
    }
    fun penjas(view: View) {
        startActivity(Intent(this, AbsenMapelPenjasActivity::class.java))
    }
}