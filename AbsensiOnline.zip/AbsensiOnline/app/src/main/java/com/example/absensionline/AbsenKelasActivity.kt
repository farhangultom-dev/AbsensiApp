package com.example.absensionline

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.absensionline.Modul.AbsensiKelas
import com.example.absensionline.Modul.siswa
import com.example.absensionline.Modul.user
import com.example.absensionline.Modul.xmia3
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_absen_kelas.*
import java.text.SimpleDateFormat

class AbsenKelasActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {
    lateinit var mDatabase: DatabaseReference
    private var dataList = ArrayList<siswa>()
    lateinit var preferences: Preferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_absen_kelas)

        preferences = Preferences(this)
        val firebaseUser = FirebaseAuth.getInstance().currentUser
        val refUsers = FirebaseDatabase.getInstance().reference.child("user").child(firebaseUser!!.uid)
        refUsers.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(p0: DataSnapshot) {

                if (p0.exists()) {
                    val user: user = p0.getValue(user::class.java)!!
                    if (user.user_level.toString() == ("walikelasxmia1")) {

                        mDatabase = FirebaseDatabase.getInstance().getReference("xmia1")
                        rvabsenkelassiswa.layoutManager = LinearLayoutManager(this@AbsenKelasActivity)
                        getkelasxmia1("")

                        et_cari_nilai.addTextChangedListener(object : TextWatcher {


                            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                            }

                            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                            }

                            override fun afterTextChanged(s: Editable) {
                                if (s.toString()!=null){

                                    getkelasxmia1(s.toString())
                                }else{
                                    getkelasxmia1("")
                                }
                            }
                        })

                    }
                    else if (user.user_level.toString() == ("walikelasxmia2")){
                        mDatabase = FirebaseDatabase.getInstance().getReference("xmia2")
                        rvabsenkelassiswa.layoutManager = LinearLayoutManager(this@AbsenKelasActivity)
                        getkelasxmia1("")

                        et_cari_nilai.addTextChangedListener(object : TextWatcher {


                            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                            }

                            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                            }

                            override fun afterTextChanged(s: Editable) {
                                if (s.toString()!=null){

                                    getkelasxmia2(s.toString())
                                }else{
                                    getkelasxmia2("")
                                }
                            }
                        })

                    }
                    else if (user.user_level.toString() == ("admin")){
                        mDatabase = FirebaseDatabase.getInstance().getReference("siswa")
                        rvabsenkelassiswa.layoutManager = LinearLayoutManager(this@AbsenKelasActivity)
                        getkelas("")

                        et_cari_nilai.addTextChangedListener(object : TextWatcher {


                            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                            }

                            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                            }

                            override fun afterTextChanged(s: Editable) {
                                if (s.toString()!=null){

                                    getkelas(s.toString())
                                }else{
                                    getkelas("")
                                }
                            }
                        })


                    }
                    else if (user.user_level.toString() == ("walikelasxmia3")) {
                        mDatabase = FirebaseDatabase.getInstance().getReference("xmia3")
                        rvabsenkelassiswa.layoutManager =
                            LinearLayoutManager(this@AbsenKelasActivity)
                        getkelasxmia3("")

                        et_cari_nilai.addTextChangedListener(object : TextWatcher {


                            override fun beforeTextChanged(
                                s: CharSequence,
                                start: Int,
                                count: Int,
                                after: Int
                            ) {
                            }

                            override fun onTextChanged(
                                s: CharSequence,
                                start: Int,
                                before: Int,
                                count: Int
                            ) {
                            }

                            override fun afterTextChanged(s: Editable) {
                                if (s.toString() != null) {

                                    getkelasxmia3(s.toString())
                                } else {
                                    getkelasxmia3("")
                                }
                            }
                        })

                    }
                    else if (user.user_level.toString() == ("walikelasxiis1")) {
                        mDatabase = FirebaseDatabase.getInstance().getReference("xiis1")
                        rvabsenkelassiswa.layoutManager =
                            LinearLayoutManager(this@AbsenKelasActivity)
                        getkelasxmia3("")

                        et_cari_nilai.addTextChangedListener(object : TextWatcher {


                            override fun beforeTextChanged(
                                s: CharSequence,
                                start: Int,
                                count: Int,
                                after: Int
                            ) {
                            }

                            override fun onTextChanged(
                                s: CharSequence,
                                start: Int,
                                before: Int,
                                count: Int
                            ) {
                            }

                            override fun afterTextChanged(s: Editable) {
                                if (s.toString() != null) {

                                    getkelasxiis1(s.toString())
                                } else {
                                    getkelasxiis1("")
                                }
                            }
                        })

                    }
                }

            }

            override fun onCancelled(p0: DatabaseError) {

            }

        })

       // val spinner = findViewById<Spinner>(R.id.spinner2)
        //val adapter = ArrayAdapter.createFromResource(
           // this,
           // R.array.Kelas,
           // android.R.layout.simple_spinner_item
        //)
        //adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        //spinner.adapter = adapter
       // spinner.setOnItemSelectedListener(this)

        val date = System.currentTimeMillis()
        val sdf = SimpleDateFormat("dd-MM-yyyy")
        val dateString: String = sdf.format(date)
        tgl.setText(dateString)
    }

    private fun getkelasxmia1(data : String) {

        val query : Query = mDatabase.orderByChild("kelas").startAt(data).endAt(data+"\uf8ff")

        query.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {


                dataList.clear()
                for (getdataSnapshot in dataSnapshot.getChildren()) {

                    val kelas = getdataSnapshot.getValue(siswa::class.java)
                    dataList.add(kelas!!)
                }
                if (dataList.isNotEmpty()) {
                    rvabsenkelassiswa.adapter =
                        AbsensiKelas(
                            dataList
                        ) {
                            val intent = Intent(
                                this@AbsenKelasActivity,
                                InputSiswaActivity::class.java
                            ).putExtra("data", it)


                            startActivity(intent)
                        }

                } else{
                    return
                }


            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@AbsenKelasActivity, "" + error.message, Toast.LENGTH_LONG).show()
            }
        })
    }
    private fun getkelasxmia2(data : String) {

        val query : Query = mDatabase.orderByChild("kelas").startAt(data).endAt(data+"\uf8ff")

        query.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {


                dataList.clear()
                for (getdataSnapshot in dataSnapshot.getChildren()) {

                    val kelas = getdataSnapshot.getValue(siswa::class.java)
                    dataList.add(kelas!!)
                }
                if (dataList.isNotEmpty()) {
                    rvabsenkelassiswa.adapter =
                        AbsensiKelas(
                            dataList
                        ) {
                            val intent = Intent(
                                this@AbsenKelasActivity,
                                InputSiswaActivity::class.java
                            ).putExtra("data", it)


                            startActivity(intent)
                        }

                } else{
                    return
                }


            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@AbsenKelasActivity, "" + error.message, Toast.LENGTH_LONG).show()
            }
        })
    }
    private fun getkelas(data : String) {

        val query : Query = mDatabase.orderByChild("kelas").startAt(data).endAt(data+"\uf8ff")

        query.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {


                dataList.clear()
                for (getdataSnapshot in dataSnapshot.getChildren()) {

                    val kelas = getdataSnapshot.getValue(siswa::class.java)
                    dataList.add(kelas!!)
                }
                if (dataList.isNotEmpty()) {
                    rvabsenkelassiswa.adapter =
                        AbsensiKelas(
                            dataList
                        ) {
                            val intent = Intent(
                                this@AbsenKelasActivity,
                                InputSiswaActivity::class.java
                            ).putExtra("data", it)


                            startActivity(intent)
                        }

                } else{
                    return
                }


            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@AbsenKelasActivity, "" + error.message, Toast.LENGTH_LONG).show()
            }
        })
    }
    private fun getkelasxmia3(data : String) {

        val query : Query = mDatabase.orderByChild("kelas").startAt(data).endAt(data+"\uf8ff")

        query.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {


                dataList.clear()
                for (getdataSnapshot in dataSnapshot.getChildren()) {

                    val kelas = getdataSnapshot.getValue(siswa::class.java)
                    dataList.add(kelas!!)
                }
                if (dataList.isNotEmpty()) {
                    rvabsenkelassiswa.adapter =
                        AbsensiKelas(
                            dataList
                        ) {
                            val intent = Intent(
                                this@AbsenKelasActivity,
                                InputSiswaActivity::class.java
                            ).putExtra("data", it)


                            startActivity(intent)
                        }

                } else{
                    return
                }


            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@AbsenKelasActivity, "" + error.message, Toast.LENGTH_LONG).show()
            }
        })
    }
    private fun getkelasxiis1(data : String) {

        val query : Query = mDatabase.orderByChild("kelas").startAt(data).endAt(data+"\uf8ff")

        query.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {


                dataList.clear()
                for (getdataSnapshot in dataSnapshot.getChildren()) {

                    val kelas = getdataSnapshot.getValue(siswa::class.java)
                    dataList.add(kelas!!)
                }
                if (dataList.isNotEmpty()) {
                    rvabsenkelassiswa.adapter =
                        AbsensiKelas(
                            dataList
                        ) {
                            val intent = Intent(
                                this@AbsenKelasActivity,
                                InputSiswaActivity::class.java
                            ).putExtra("data", it)


                            startActivity(intent)
                        }

                } else{
                    return
                }


            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@AbsenKelasActivity, "" + error.message, Toast.LENGTH_LONG).show()
            }
        })
    }


    override fun onNothingSelected(parent: AdapterView<*>?) {
        TODO("Not yet implemented")
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        val text = parent!!.getItemAtPosition(position).toString()
        Toast.makeText(parent.context, text, Toast.LENGTH_SHORT).show()
    }
}