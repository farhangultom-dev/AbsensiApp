package com.example.absensionline

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.absensionline.Modul.siswa
import com.example.absensionline.Modul.user
import com.example.absensionline.Modul.xmia1
import com.example.absensionline.Modul.xmia2
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_input_siswa.*
import java.util.*

class InputSiswaActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {

    lateinit var progressBar: ProgressDialog
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input_siswa)

        val spinner = findViewById<Spinner>(R.id.spinner)
        val adapter = ArrayAdapter.createFromResource(
            this,
            R.array.Kelas,
            android.R.layout.simple_spinner_item
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        spinner.setOnItemSelectedListener(this)

        btnTambahSiswa.setOnClickListener {
            tambahSiswa()
        }
    }

    private fun tambahSiswa() {  val progressBar = ProgressDialog(this)
        progressBar.setMessage("Mohon tunggu...")
        progressBar.show()
        val uid_siswa = UUID.randomUUID()
        val kelas = spinner.selectedItem.toString()
        if (kelas == ("X MIA 1")) {

            val db = FirebaseDatabase.getInstance().getReference("xmia1/$uid_siswa")


            db.setValue(
                xmia1(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )

            val dbs = FirebaseDatabase.getInstance().getReference("siswa/$uid_siswa")


            dbs.setValue(
                siswa(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()



                )
            )
                .addOnSuccessListener {
                    progressBar.dismiss()
                    startActivity(Intent(this, InputSiswaActivity::class.java))
                    finish()
                }
                .addOnFailureListener {

                }
        }
        else if (kelas == ("X MIA 2")){
            val db = FirebaseDatabase.getInstance().getReference("xmia2/$uid_siswa")


            db.setValue(
                xmia2(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )

            val dbs = FirebaseDatabase.getInstance().getReference("siswa/$uid_siswa")


            dbs.setValue(
                siswa(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )


                .addOnSuccessListener {
                    progressBar.dismiss()
                    startActivity(Intent(this, InputSiswaActivity::class.java))
                    finish()
                }
                .addOnFailureListener {

                }
        }
        else if (kelas == ("X MIA 3")){
            val db = FirebaseDatabase.getInstance().getReference("xmia3/$uid_siswa")


            db.setValue(
                xmia2(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )

            val dbs = FirebaseDatabase.getInstance().getReference("siswa/$uid_siswa")


            dbs.setValue(
                siswa(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )


                .addOnSuccessListener {
                    progressBar.dismiss()
                    startActivity(Intent(this, InputSiswaActivity::class.java))
                    finish()
                }
                .addOnFailureListener {

                }
        }
        else if (kelas == ("X IIS 1")){
            val db = FirebaseDatabase.getInstance().getReference("xiis1/$uid_siswa")


            db.setValue(
                xmia2(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )

            val dbs = FirebaseDatabase.getInstance().getReference("siswa/$uid_siswa")


            dbs.setValue(
                siswa(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )


                .addOnSuccessListener {
                    progressBar.dismiss()
                    startActivity(Intent(this, InputSiswaActivity::class.java))
                    finish()
                }
                .addOnFailureListener {

                }
        }
        else if (kelas == ("X IIS 2")){
            val db = FirebaseDatabase.getInstance().getReference("xiis2/$uid_siswa")


            db.setValue(
                xmia2(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )

            val dbs = FirebaseDatabase.getInstance().getReference("siswa/$uid_siswa")


            dbs.setValue(
                siswa(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )


                .addOnSuccessListener {
                    progressBar.dismiss()
                    startActivity(Intent(this, InputSiswaActivity::class.java))
                    finish()
                }
                .addOnFailureListener {

                }
        }
        else if (kelas == ("X IIS 3")){
            val db = FirebaseDatabase.getInstance().getReference("xiis3/$uid_siswa")


            db.setValue(
                xmia2(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )

            val dbs = FirebaseDatabase.getInstance().getReference("siswa/$uid_siswa")


            dbs.setValue(
                siswa(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )


                .addOnSuccessListener {
                    progressBar.dismiss()
                    startActivity(Intent(this, InputSiswaActivity::class.java))
                    finish()
                }
                .addOnFailureListener {

                }
        }else if (kelas == ("X IIS 4")){
            val db = FirebaseDatabase.getInstance().getReference("xiis4/$uid_siswa")


            db.setValue(
                xmia2(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )

            val dbs = FirebaseDatabase.getInstance().getReference("siswa/$uid_siswa")


            dbs.setValue(
                siswa(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )


                .addOnSuccessListener {
                    progressBar.dismiss()
                    startActivity(Intent(this, InputSiswaActivity::class.java))
                    finish()
                }
                .addOnFailureListener {

                }
        }else if (kelas == ("X IIS 5")){
            val db = FirebaseDatabase.getInstance().getReference("xiis5/$uid_siswa")


            db.setValue(
                xmia2(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )

            val dbs = FirebaseDatabase.getInstance().getReference("siswa/$uid_siswa")


            dbs.setValue(
                siswa(
                    nama.text.toString().toLowerCase(),
                    NIS.text.toString(),
                    tglLahir.text.toString(),
                    kelas,
                    noHpOrtu.text.toString()


                )
            )


                .addOnSuccessListener {
                    progressBar.dismiss()
                    startActivity(Intent(this, InputSiswaActivity::class.java))
                    finish()
                }
                .addOnFailureListener {

                }
        }
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {
        TODO("Not yet implemented")
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        val text = parent!!.getItemAtPosition(position).toString()
        Toast.makeText(parent.context, text, Toast.LENGTH_SHORT).show()
    }
}