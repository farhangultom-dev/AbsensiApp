package com.example.absensionline.Modul

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class xmia2 (
    var nama : String ?="",
    var nis : String ?="",
    var tgllahir : String ?= "",
    var kelas : String ?= "",
    var nohportu : String ?= ""
): Parcelable