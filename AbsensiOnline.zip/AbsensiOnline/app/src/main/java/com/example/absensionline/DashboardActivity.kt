package com.example.absensionline

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.absensionline.Modul.user
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.android.synthetic.main.activity_dashboard.*

class DashboardActivity : AppCompatActivity() {
    private lateinit var firebaseauth: FirebaseAuth
    lateinit var preferences: Preferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        preferences = Preferences(this)
        val firebaseUser = FirebaseAuth.getInstance().currentUser
        val refUsers = FirebaseDatabase.getInstance().reference.child("user").child(firebaseUser!!.uid)
        refUsers.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(p0: DataSnapshot) {

                if (p0.exists()) {
                    val user: user = p0.getValue(user::class.java)!!
                    if (user.user_level.toString() == ("admin")) {
                        cv_profilsekolah.visibility = View.VISIBLE
                        cv_presensisiswa.visibility = View.VISIBLE
                        cv_logout.visibility = View.VISIBLE
                        cv_kelas.visibility = View.VISIBLE

                    } else {
                        cv_kelas.visibility = View.GONE

                    }


                }

            }

            override fun onCancelled(p0: DatabaseError) {

            }

        })

        cv_logout.setOnClickListener {
            preferences.setValues("status", "2")
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this, MasukActivity::class.java))
            finishAffinity()
        }

        cv_profilsekolah.setOnClickListener {
            startActivity(Intent(this, StrukturActivity::class.java))
        }

        cv_kelas.setOnClickListener {
            startActivity(Intent(this, KelasActivity::class.java))
        }

        cv_presensisiswa.setOnClickListener {
            startActivity(Intent(this, LaporanPresensiActivity::class.java))
        }
    }

}