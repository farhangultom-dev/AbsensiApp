package com.example.absensionline

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import com.example.absensionline.Modul.user
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_register.*

class RegisterActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        auth = FirebaseAuth.getInstance()
        btn_daftar.setOnClickListener {
            daftar()
        }
    }

    private fun daftar() {
        val progressBar = ProgressDialog(this)
        progressBar.setMessage("Mohon tunggu...")
        progressBar.show()

        if (Email.text.toString().isEmpty()){
            progressBar.dismiss()
            Email.error = "Masukkan Email Kamu"
            Email.requestFocus()
            return
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(Email.text.toString()).matches()) {
            progressBar.dismiss()
            Email.error = "Masukkan Valid Email Kamu"
            Email.requestFocus()
            return
        }

        if (password.text.toString().isEmpty()){
            progressBar.dismiss()
            password.error = "Masukkan Password Kamu"
            password.requestFocus()
            return
        }

        if (konfirmasipassword.text.toString().isEmpty()){
            progressBar.dismiss()
            konfirmasipassword.error = "Masukkan Password Kamu"
            konfirmasipassword.requestFocus()
            return
        }

        if (password.length()<6){
            progressBar.dismiss()
            password.error = "Masukkan Password Minimal 6 karakter"
            password.requestFocus()
        }

        if (konfirmasipassword.length()<6){
            progressBar.dismiss()
            konfirmasipassword.error = "Masukkan Password Minimal 6 karakter"
            konfirmasipassword.requestFocus()
        }

        if (konfirmasipassword.text.toString() != password.text.toString()){
            progressBar.dismiss()
            konfirmasipassword.error = "konfirmasi password tidak cocok dengan password"
            konfirmasipassword.requestFocus()
        }

        auth.createUserWithEmailAndPassword(Email.text.toString(), password.text.toString())
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {


                    val user = auth.currentUser
                    user?.sendEmailVerification()
                        ?.addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                progressBar.dismiss()
                                simpanDataUser()
                            }
                        }

                } else {
                    progressBar.dismiss()
                    Toast.makeText(baseContext, "Sign up Gagal",
                        Toast.LENGTH_SHORT).show()
                }

            }
    }

    private fun simpanDataUser() {
        val progressBar = ProgressDialog(this)
        progressBar.setMessage("Mohon tunggu...")
        progressBar.show()

        val uid = FirebaseAuth.getInstance().uid
        val db = FirebaseDatabase.getInstance().getReference("user/$uid")

        db.setValue(
            user(
                uid.toString(),
                Email.text.toString()


            )
        )
            .addOnSuccessListener {
                progressBar.dismiss()
                startActivity(Intent(this, MasukActivity::class.java))
                finish()
            }
            .addOnFailureListener {

            }
    }
    }